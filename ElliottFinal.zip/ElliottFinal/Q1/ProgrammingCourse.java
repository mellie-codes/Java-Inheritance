/*
 * 
 * Final Exam
 * Q1
 * 
 * File: ProgrammingCourse.java
 * 
 * 
 * Extends Course
 * Gets and sets course programmingLanguage
 * Calculates revenue using enrollmentLimit and coursePrice
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */

final public class ProgrammingCourse extends Course {
	
	// ProgrammingCourse Attributes
	private String programmingLanguage;
	
	// ProgrammingCourse constructor
	// Inherits Course attributes
	public ProgrammingCourse(String courseID, String courseTitle, int enrollmentLimit, double coursePrice, Faculty faculty, String programmingLanguage) {
        super(courseID, courseTitle, enrollmentLimit, coursePrice, faculty);
        this.programmingLanguage = programmingLanguage;
    }
	
	// Get and set programmingLanguage
	public String getProgrammingLanguage() {
        return programmingLanguage;
    }
    public void setProgrammingLanguage(String programmingLanguage) {
        this.programmingLanguage = programmingLanguage;
    }
	
    // Override Inherited behavior
 	// calculate revenue with formula coursePrice * enrollmentLimit
	@Override
    public void calculateRevenue() {
        if (enrollmentLimit > 0) {
        	double revenue = getCoursePrice() * getEnrollmentLimit();
            System.out.println("This course generates a revenue of: $" + revenue);
        } else {
            System.out.println("This course generates no revenue. ");
        }
    }
	
	// Override toString method
	@Override
    public String toString() {
        return "\nProgramming language: " + programmingLanguage + super.toString();
    }

}
