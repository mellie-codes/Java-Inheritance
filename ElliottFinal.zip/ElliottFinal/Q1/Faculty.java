/*
 * 
 * Final Exam
 * Q1
 * 
 * File: Faculty.java
 * 
 * 
 * Connected to Course through Aggregation
 * Gets and sets facultyID, facultyName
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */


public class Faculty {
	
	// Faculty attributes
	private String facultyID;
    private String facultyName;
    
    // Faculty Constructor
    public Faculty(String facultyID, String facultyName) {
        this.facultyID = facultyID;
        this.facultyName = facultyName;
    }
    
    // Get and set facultyID
    public String getFacultyID() {
        return facultyID;
    }
    public void setFacultyID(String facultyID) {
        this.facultyID = facultyID;
    }

    // Get and set facultyName
    public String getfacultyName() {
        return facultyName;
    }
    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }

    // Override toString method
    @Override
    public String toString() {
        return "Faculty Name: " + facultyName + "\nFaculty ID: " + facultyID;
    }

}
