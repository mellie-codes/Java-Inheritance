/*
 * 
 * Final Exam
 * Q1
 * 
 * File: UseCourse.java
 * 
 * 
 * Testing relationships between classes
 * Create ProgrammingCourse objects
 * Add objects to ArrayList
 * Display object information
 * Calculate revenue for ProgrammingCourse
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */

import java.util.ArrayList;

public class UseCourse {
	
	// create ArrayList to store Course objects
	private static ArrayList<Course> courseList = new ArrayList<>();
	
	public static void main(String[] args) {
		
		// Create new ProgrammingCourse objects
		// include values for courseID, courseTitle, enrollmentLimit, coursePrice, instantiate new Faculty, programmingLanguage
		ProgrammingCourse programmingCourse1 = new ProgrammingCourse("INFO C210", "Problem Solving and Programming I", 28, 300.0, new Faculty ("25555", "Awny Alnusair"), "Java");
		ProgrammingCourse programmingCourse2 = new ProgrammingCourse("INFO C211", "Problem Solving and Programming II", 26, 375.0, new Faculty ("25556", "Hisham Sliman"), "Java");
		
		// add ProgrammingCourse to ArrayList
        courseList.add(programmingCourse1);
        courseList.add(programmingCourse2);
        
        // for each Course in ArrayList, print out their information
        // calculate each course revenue
        for (Course course: courseList) {
        	System.out.println(course.toString());
        	course.calculateRevenue();
        }
        
    }
}
