/*
 * 
 * Final Exam
 * Q1
 * 
 * File: Course.java
 * 
 * 
 * Abstract class with one child class
 * Superclass to ProgrammingCourse
 * Connected to Faculty through Aggregation
 * Gets and sets values for courseID, courseTitle, 
 * 		enrollmentLimit, coursePrice, and faculty
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */

public abstract class Course {
	
	// Course attributes shared with subclass
    protected String courseID;
    protected String courseTitle;
    protected double enrollmentLimit;
    protected double coursePrice;
    protected Faculty faculty;
    
    // Course Constructor
    public Course(String courseID, String courseTitle, int enrollmentLimit, double coursePrice, Faculty faculty) {
        this.courseID = courseID;
        this.courseTitle = courseTitle;
        this.enrollmentLimit = enrollmentLimit;
        this.coursePrice = coursePrice;
        this.faculty = faculty;
    }
    
    // get and set courseID
    public String getCourseID() {
        return courseID;
    }
    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }
    
    // get and set courseTitle
    public String getCourseTitle() {
        return courseTitle;
    }
    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }
    
    // get and set enrollmentLimit
    public double getEnrollmentLimit() {
        return enrollmentLimit;
    }
    public void setEnrollmentLimit(double enrollmentLimit) {
        this.enrollmentLimit = enrollmentLimit;
    }
    
    // get and set coursePrice
    public double getCoursePrice() {
        return coursePrice;
    }
    public void setCoursePrice(double coursePrice) {
        this.coursePrice = coursePrice;
    }
    
    // get and set faculty
    public Faculty getFaculty() {
        return faculty;
    }
    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }
    
    // abstract behavior to be inherited by subclass
    public abstract void calculateRevenue();
    
    // Override toString method
    @Override
    public String toString() {
        return "\nCourse ID: " + courseID + "\nCourse Title: " + courseTitle + "\nEnrollment Limit: " + enrollmentLimit + "\nCourse Price: " + coursePrice + "\n" + faculty.toString();
    }

}
