/*
 * 
 * Final Exam
 * Q2
 * 
 * File: Square.java
 * 
 * 
 * Extends TwoDimensionalShape
 * Calculates the area of a square
 * using values for side1 and side2
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */


final public class Square extends TwoDimensionalShape {
	
	// Square constructor
	// Inherits attributes from Shape and TwoDimensionalShape
	public Square(String color, Point point, double side1, double side2) {
        super(color, point, side1, side2);
    }
	
	// Override Inherited behavior
	// calculate area with formula side * side
	@Override
    public double getArea() {
        return getSide1() * getSide2();
    }

}
