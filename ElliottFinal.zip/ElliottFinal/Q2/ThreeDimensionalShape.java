/*
 * 
 * Final Exam
 * Q2
 * 
 * File: ThreeDimensionalShape.java
 * 
 * 
 * Extends Shape
 * Abstract class with one child class
 * Superclass to Cube
 * Gets and sets values for side1, side2, and side3
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */


public abstract class ThreeDimensionalShape extends Shape {
	
	// ThreeDimensionalShape attributes shared with subclass
	private double side1;
	private double side2;
	private double side3;
	
	// ThreeDimensionalShape constructor
	// Inherits attributes from Shape
	public ThreeDimensionalShape(String color, Point point, double side1, double side2, double side3) {
        super(color, point);
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }
	
	// get and set side1
	public double getSide1() {
        return side1;
    }

    public void setSide1(double side1) {
        this.side1 = side1;
    }
    
    // get and set side2
    public double getSide2() {
        return side2;
    }
    public void setSide2(double side2) {
        this.side2 = side2;
    }
    
    // get and set side3
    public double getSide3() {
        return side3;
    }
    public void setSide3(double side3) {
        this.side3 = side3;
    }
	
    // abstract behaviors to be inherited by subclass
	public abstract double getArea();
	public abstract double getVolume();

}
