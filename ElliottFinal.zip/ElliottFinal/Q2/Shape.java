
/** Abstract Shape
 *
 * @author:
 * Shape.java
 *
 */
public abstract class Shape {
	String color;
	Point point; // Aggregation between Shape and Point

	/** Shape constructor
	 *
	 * @param color
	 * @param point
	 */
	Shape(String color, Point point) {
		this.color = color;
		this.point = point;
	}

	/** abstract get area
	 *
	 * @return
	 */
	public abstract double getArea();

	/** get Color
	 *
	 * @return color
	 */
	public String getColor() {
		return this.color;
	}

	/** get Point
	 *
	 * @return point
	 */
	public Point getPoint() {
		return this.point;
	}

	/** set color
	 *
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/** set Point
	 *
	 * @param point
	 */
	public void setPoint(Point point) {
		this.point = point;
	}
}


