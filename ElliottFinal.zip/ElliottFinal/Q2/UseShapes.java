/*
 * 
 * Final Exam
 * Q2
 * 
 * File: UseShapes.java
 * 
 * 
 * Testing relationships between classes
 * Create Square objects
 * Create Cube objects
 * Add objects to ArrayList
 * Display object information
 * Calculate Area for Square and Cube
 * Calculate Volume for Cube
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */

import java.util.ArrayList;

public class UseShapes {

// create ArrayList to store Shape objects
private static ArrayList<Shape> shapeList = new ArrayList<>();
	
	public static void main(String[] args) {
	
		// Create new Square objects
		// include values for color, instantiate new Point, side1, side2
		Square square1 = new Square ("blue", new Point(0,0), 4.0, 4.0);
		Square square2 = new Square ("orange", new Point(1,4), 3.0, 3.0);
		
		// add Squares to ArrayList
        shapeList.add(square1);
        shapeList.add(square2);
        
        // Create new Cube objects
     	// include values for color, instantiate new Point, side1, side2, side3
        Cube cube1 = new Cube ("pink", new Point(3,7), 4.0, 4.0, 4.0);
        Cube cube2 = new Cube ("aqua", new Point(2,4), 1.0, 1.0, 1.0);
		
        // add Cubes to ArrayList
        shapeList.add(cube1);
        shapeList.add(cube2);
        
        // for each Shape in ArrayList, print out their information
        for (Shape shape: shapeList) {
        	// specific to objects of TwoDimensionalShape
        	if (shape instanceof TwoDimensionalShape) {
        		System.out.println("\nTwo-Dimensional Shape: Square");
        		System.out.println("\nColor: " + shape.getColor());
        		System.out.println("\nCoordinates: " + shape.getPoint());
        		System.out.println("\nArea: " + ((Square) shape).getArea());
        	}
        	// specific to objects of ThreeDimensionalShape
        	if (shape instanceof ThreeDimensionalShape) {
        		System.out.println("\nThree-Dimensional Shape: Cube");
        		System.out.println("\nColor: " + shape.getColor());
        		System.out.println("\nCoordinates: " + shape.getPoint());
        		System.out.println("\nArea: " + ((Cube) shape).getArea());
        		System.out.println("\nVolume: " + ((Cube) shape).getVolume());
        	}

        }
        
    }

}
