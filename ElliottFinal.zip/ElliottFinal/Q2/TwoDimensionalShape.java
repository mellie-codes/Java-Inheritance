/*
 * 
 * Final Exam
 * Q2
 * 
 * File: TwoDimensionalShape.java
 * 
 * 
 * Extends Shape
 * Abstract class with one child class
 * Superclass to Square
 * Gets and sets values for side1, side2
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */

public abstract class TwoDimensionalShape extends Shape {
	
	// TwoDimensionalShape attributes shared with subclass
	private double side1;
	private double side2;
	
	// TwoDimensionalShape constructor
	// Inherits attributes from Shape
	public TwoDimensionalShape(String color, Point point, double side1, double side2) {
        super(color, point);
        this.side1 = side1;
        this.side2 = side2;
    }
	
	// get and set value for side1
	public double getSide1() {
        return side1;
    }

    public void setSide1(double side1) {
        this.side1 = side1;
    }
    
    // get and set value for side2
    public double getSide2() {
        return side2;
    }
    public void setSide2(double side2) {
        this.side2 = side2;
    }
	
    // abstract behavior to be inherited by subclass
	public abstract double getArea();

}
