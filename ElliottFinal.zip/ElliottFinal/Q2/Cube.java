/*
 * 
 * Final Exam
 * Q2
 * 
 * File: Cube.java
 * 
 * 
 * Extends ThreeDimensionalShape
 * Calculates the area of a cube
 * Calculates the volume of a cube
 * using values for side1, side2, and side3
 * 
 * 
 * @author: Morgan Elliott
 * @version 1.0
 * @date: 10/21/24
 * 
 */


final public class Cube extends ThreeDimensionalShape {
	
	// Cube constructor
	// Inherits attributes from Shape and ThreeDimensionalShape
	public Cube(String color, Point point, double side1, double side2, double side3) {
        super(color, point, side1, side2, side3);
    }
	
	// Override Inherited behavior
	// calculate area with formula side * side * 6
	@Override
    public double getArea() {
        return getSide1() * getSide2() * 6;
    }
	
	// Override Inherited behavior
	// calculate volume with formula side * side * side
	@Override
    public double getVolume() {
        return getSide1() * getSide2() * getSide3();
    }

}
